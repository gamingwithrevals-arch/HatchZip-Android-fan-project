package dev.hatchzip.android

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HatchZipApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HatchZipApp() {
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf<String?>(null) }
    var showAbout by remember { mutableStateOf(false) }

    val archivePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            selectedName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected archive"
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF9CCAFF),
            secondary = androidx.compose.ui.graphics.Color(0xFFB8C8E5),
            surface = androidx.compose.ui.graphics.Color(0xFF111318),
            background = androidx.compose.ui.graphics.Color(0xFF111318)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("HatchZip", fontWeight = FontWeight.Bold)
                            Text("Space-saving archive extraction", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showAbout = true }) {
                            Icon(Icons.Default.Info, contentDescription = "About")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = true, onClick = {}, icon = {
                            Icon(Icons.Default.Archive, contentDescription = null)
                        }, label = { Text("Extract") }
                    )
                    NavigationBarItem(
                        selected = false, onClick = { showAbout = true }, icon = {
                            Icon(Icons.Default.Settings, contentDescription = null)
                        }, label = { Text("About") }
                    )
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp)
            ) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(
                                Modifier.size(52.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = .15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Storage, contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                            }
                            Text("Make room for big games", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "Choose an archive to get started. The Android extraction engine is not connected in this starter build yet.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = { archivePicker.launch(arrayOf("*/*")) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Choose archive")
                            }
                        }
                    }
                }
                item {
                    Text("Selected archive", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Archive, contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(selectedName ?: "No archive selected", fontWeight = FontWeight.Medium)
                                Text(
                                    if (selectedUri == null) "ZIP, 7z, TAR and other formats depend on engine support"
                                    else "File selected · extraction is not available in this starter",
                                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                item {
                    Text("How it will work", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    FeatureRow("1", "Select an archive", "Browse files using Android's system file picker.")
                    FeatureRow("2", "Choose destination", "Select a folder and review available storage.")
                    FeatureRow("3", "Extract safely", "The HatchZip Rust engine must be ported and connected before extraction can run.")
                }
                item {
                    Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(16.dp)) {
                        Text(
                            "Prototype only: this APK does not extract archives and does not free archive space. Do not rely on it for real files yet.",
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }
        if (showAbout) {
            AlertDialog(
                onDismissRequest = { showAbout = false },
                title = { Text("HatchZip for Android") },
                text = { Text("Android UI starter. The original HatchZip Rust core still needs an Android platform implementation and JNI integration.") },
                confirmButton = { TextButton(onClick = { showAbout = false }) { Text("OK") } }
            )
        }
    }
}

@Composable
private fun FeatureRow(number: String, title: String, detail: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Box(
            Modifier.size(32.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = .15f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(number, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
    }
}
