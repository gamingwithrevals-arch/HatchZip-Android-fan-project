# HatchZip Android Starter

This repository builds a **UI prototype APK** using GitHub Actions. It is not yet a working HatchZip extractor.

## Build the APK from your phone

1. Create a GitHub repository and upload the contents of this folder (not the enclosing folder itself).
2. Open the repository's **Actions** tab.
3. Select **Build HatchZip Android APK**.
4. Tap **Run workflow** and confirm.
5. Wait for the workflow to finish successfully.
6. Open the completed run, find **Artifacts**, and download `HatchZip-Android-debug`.
7. Extract the downloaded artifact ZIP and install `app-debug.apk` on your phone. Android may ask you to allow installs from that download app.

## Current status

Included:
- Native Android app shell using Kotlin, Jetpack Compose and Material 3.
- System archive file picker.
- Modern dark interface scaffold.
- GitHub Actions workflow that builds and uploads a debug APK.

Not included yet:
- HatchZip Rust engine compiled for Android.
- Android platform module for safe file operations and hole punching.
- JNI bridge.
- Actual archive extraction, progressive space reclamation, cancellation, or recovery.

**Do not use this prototype to extract or manage important archives.** Selecting a file does not mean it can extract it.

## Next engineering step

Port `hatchzip-core` to Android. Its `crates/core/src/platform/mod.rs` currently has no Android platform module and explicitly rejects unsupported targets. The Android implementation must carefully adapt filesystem operations, symlink/mode behavior, syncing and hole punching. Android's Storage Access Framework provides document URIs, not ordinary filesystem paths; use a safe design for app-owned files and explicitly document limitations for user-selected document-provider locations. Then expose engine operations to Kotlin through JNI and add real-device tests proving that extraction integrity and progressive space reclamation work.

## License

Keep the original HatchZip license files and notices when incorporating its source. Check all dependency licenses before distributing a release APK, especially if enabling the optional RAR/UnRAR feature.
