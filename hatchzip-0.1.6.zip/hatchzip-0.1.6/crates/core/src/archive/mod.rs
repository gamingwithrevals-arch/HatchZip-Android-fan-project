//! What the engine needs from an archive format: the archive split into
//! units, byte ranges that can be truncated away once every file in them is
//! safely on disk, and a way to decode one unit.

#[cfg(feature = "rar")]
mod rar;
pub mod resumable;
mod sevenz;
pub mod storage;
mod tar;
pub mod targz;
mod zip;

use std::io::Read;
use std::path::{Component, Path, PathBuf};
use std::sync::Arc;
use std::time::SystemTime;

use anyhow::{Context, Result, bail};

use crate::journal::Resume;
use storage::{Storage, Tail};
use targz::Solid;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Kind {
    File,
    Dir,
    /// The link target is the item's data.
    Symlink,
    /// Hard links point at an earlier entry, which is extracted later than
    /// the link when going from the end, so they are made at the very end.
    HardLink(PathBuf),
}

#[derive(Clone, Debug)]
pub struct Item {
    pub path: PathBuf,
    pub size: u64,
    pub kind: Kind,
    pub mode: Option<u32>,
    pub mtime: Option<SystemTime>,
}

pub struct Unit {
    /// Where the unit's bytes begin. Once it is committed the archive is
    /// truncated to this offset.
    pub start: u64,
    /// The format's own handle for the unit: a ZIP entry index, a 7z block.
    pub key: usize,
    pub items: Vec<Item>,
    /// Decoding it needs the archive's password.
    pub encrypted: bool,
}

/// The archive is encrypted and nothing can be read without its password.
/// Front ends look for this error to ask for one.
#[derive(Debug)]
pub struct PasswordNeeded;

impl std::fmt::Display for PasswordNeeded {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("this archive is password protected")
    }
}

impl std::error::Error for PasswordNeeded {}

/// The password doesn't open the archive.
#[derive(Debug)]
pub struct WrongPassword;

impl std::fmt::Display for WrongPassword {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("incorrect password")
    }
}

impl std::error::Error for WrongPassword {}

/// The archive is damaged, found while opening it and before anything was
/// touched. Front ends look for this error to report damage as such.
#[derive(Debug)]
pub struct Damaged(pub anyhow::Error);

impl std::fmt::Display for Damaged {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{:#}", self.0)
    }
}

impl std::error::Error for Damaged {}

/// The format name of RAR archives in the journal.
pub const RAR: &str = "rar";

/// Whether this build extracts RAR archives. Builds without UnRAR refuse
/// them before anything is touched.
pub const RAR_SUPPORTED: bool = cfg!(feature = "rar");

/// Why a build without UnRAR refuses a RAR archive.
pub fn no_rar() -> anyhow::Error {
    anyhow::anyhow!(
        "this build of HatchZip does not include RAR support, and the archive was not \
         modified. Download the release build from hatchzip.dev or \
         github.com/xevrion/hatchzip/releases"
    )
}

/// How the password of an encrypted archive is proven before anything is
/// touched.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PasswordCheck {
    /// Decode the start of the smallest encrypted unit: a wrong password
    /// fails at once, or within the first blocks.
    Sample,
    /// The headers hold a check value for the password, so
    /// [`Format::prove_password`] answers without decoding anything.
    Headers,
    /// Only the checksum at the end of a file can tell, so the smallest
    /// encrypted unit is decoded whole, writing nothing.
    WholeUnit,
}

impl Unit {
    /// Saturates instead of wrapping: sizes come straight from the archive.
    pub fn size(&self) -> u64 {
        self.items
            .iter()
            .fold(0u64, |sum, i| sum.saturating_add(i.size))
    }
}

pub trait Format: Send + Sync {
    /// A worker decodes units on one thread. `threads` is a hint for codecs
    /// that can decode a single stream on several cores.
    fn worker(&self, threads: u32) -> Result<Box<dyn Worker + '_>>;

    /// For a unit holding one file whose data [`resumable`] can decode from
    /// the middle: where that data lies. Such units can free their archive
    /// bytes while they are extracted instead of only once they are done.
    fn stream(&self, _unit: &Unit) -> Result<Option<Stream>> {
        Ok(None)
    }

    /// For an archive that is one compressed stream, decodable only from the
    /// front: its single unit, extracted front to back while the bytes behind
    /// the decoder are freed.
    fn solid(&self) -> Option<&Solid> {
        None
    }

    /// The decoder finds a unit only by reading everything before it, and
    /// one handle can't be shared between threads. A batch is then decoded
    /// on one thread by one worker, lowest unit first, so the worker can
    /// walk forward instead of starting over for every unit.
    fn serial(&self) -> bool {
        false
    }

    /// Why the archive can't be extracted in place, if it can't: it can
    /// still be extracted while it is kept.
    fn refuses_in_place(&self) -> Option<String> {
        None
    }

    fn password_check(&self) -> PasswordCheck {
        PasswordCheck::Sample
    }

    /// Proves the password from the headers alone; only called when
    /// [`password_check`](Self::password_check) says it can.
    fn prove_password(&self) -> Result<()> {
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Codec {
    Stored,
    /// Raw deflate, as ZIP stores it.
    Deflate,
}

#[derive(Clone, Debug)]
pub struct Stream {
    /// Where the file's data begins. The headers before it stay untouched
    /// until the unit is committed, so the archive still parses on resume.
    pub data_start: u64,
    /// Length of the data in the archive.
    pub packed: u64,
    pub codec: Codec,
    /// CRC-32 of the output, if the format records one.
    pub crc: Option<u32>,
}

pub trait Worker {
    /// Decodes `unit`, handing each item to `sink` in order.
    fn extract(&mut self, unit: &Unit, sink: &mut dyn Sink) -> Result<()>;
}

pub trait Sink {
    fn item(&mut self, item: &Item, data: &mut dyn Read) -> Result<()>;
}

pub struct Opened {
    pub name: &'static str,
    pub format: Box<dyn Format>,
    pub units: Vec<Unit>,
    /// Everything from here to the end is saved before anything is reclaimed.
    pub tail_start: u64,
}

/// Parses the archive. `resume` carries the format recorded by an earlier
/// run, the tail it saved and its resume point, which a compressed tar is
/// read from; a fresh run sniffs the format instead. The password is only
/// needed for encrypted archives; whether it is right is found out when a
/// unit is decoded (see `Job::check_password`).
pub fn open(
    storage: &Arc<Storage>,
    resume: Option<(&str, Arc<Tail>, Option<&Resume>)>,
    password: Option<&str>,
) -> Result<Opened> {
    let (name, tail, point) = match resume {
        Some((name, tail, point)) => (name.to_string(), Some(tail), point),
        None => (sniff(storage)?.to_string(), None, None),
    };
    match name.as_str() {
        "zip" => zip::open(storage, tail, password),
        "7z" => sevenz::open(storage, tail, password),
        "tar" => tar::open(storage, tail),
        #[cfg(feature = "rar")]
        RAR => rar::open(storage, tail.is_some(), password),
        #[cfg(not(feature = "rar"))]
        RAR => Err(no_rar()),
        targz::NAME => targz::open(storage, point),
        other => bail!("unknown archive format '{other}' in the journal"),
    }
}

/// What turns the first `keep` bytes of a half-extracted archive back into an
/// archive any tool opens.
pub struct NewIndex {
    /// Written at `keep`.
    pub append: Vec<u8>,
    /// Written over bytes below `keep`: the 7z start header, which has to
    /// point at the new header.
    pub patches: Vec<(u64, Vec<u8>)>,
}

/// Builds the [`NewIndex`] for the entries that start below `keep`, from
/// the tail an earlier run saved. `hard_links` are tar links already cut off
/// whose targets are still in the archive.
pub fn rebuild_index(
    format: &str,
    storage: &Storage,
    tail: Arc<Tail>,
    keep: u64,
    hard_links: &[(&Path, &Path)],
) -> Result<NewIndex> {
    let (append, patches) = match format {
        "zip" => (zip::rebuild_index(&tail, keep)?, Vec::new()),
        "tar" => (tar::closing(hard_links)?, Vec::new()),
        "7z" => {
            let (header, start) = sevenz::rebuild_header(storage, tail, keep)?;
            (header, vec![(0, start)])
        }
        // No index: the last volume left only needs its end header back.
        #[cfg(feature = "rar")]
        RAR => (rar::closing(storage, keep)?, Vec::new()),
        #[cfg(not(feature = "rar"))]
        RAR => return Err(no_rar()),
        other => bail!("unknown archive format '{other}' in the journal"),
    };
    Ok(NewIndex { append, patches })
}

fn sniff(storage: &Storage) -> Result<&'static str> {
    let mut head = [0u8; 512];
    let mut r = storage.reader(None);
    let n = read_up_to(&mut r, &mut head)?;
    let head = &head[..n];
    let starts = |magic: &[u8]| head.starts_with(magic);
    if starts(b"7z\xBC\xAF\x27\x1C") {
        return Ok("7z");
    }
    let is_tar = |head: &[u8]| head.len() >= 263 && &head[257..262] == b"ustar";
    if is_tar(head) {
        return Ok("tar");
    }
    let ext = storage.primary().to_string_lossy().to_ascii_lowercase();
    if starts(b"\x1F\x8B") {
        // Look inside: a plain .gz of one file is not an archive.
        let mut gz = resumable::Gzip::new(
            storage.reader(None),
            storage.original_len(),
            &resumable::GzPoint::start(),
        )?;
        let mut first = [0u8; 512];
        let mut n = 0;
        while n < first.len() {
            match gz
                .read(&mut first[n..])
                .context("reading the start of the compressed stream")?
            {
                0 => break,
                k => n += k,
            }
        }
        let named = [".tar.gz", ".tgz", ".taz"]
            .iter()
            .any(|e| ext.ends_with(e) || ext.contains(&format!("{e}.")));
        if is_tar(&first[..n]) || named {
            return Ok(targz::NAME);
        }
        bail!(
            "this is a gzip-compressed file that does not contain a tar archive. Only \
             compressed tar archives (.tar.gz) can be extracted"
        );
    }
    if starts(b"\x28\xB5\x2F\xFD") || starts(b"\xFD7zXZ\x00") || starts(b"BZh") {
        bail!(
            "this is a compressed stream (.zst, .xz or .bz2). In-place extraction of these \
             compressed streams is not supported yet"
        );
    }
    if starts(b"Rar!\x1A\x07") {
        return Ok(RAR);
    }
    if ext.ends_with(".tar") || ext.contains(".tar.") {
        return Ok("tar");
    }
    // Anything else gets a ZIP parse: self-extracting archives put an
    // executable in front, so the signature isn't at the start.
    Ok("zip")
}

fn read_up_to(r: &mut impl Read, buf: &mut [u8]) -> std::io::Result<usize> {
    let mut n = 0;
    while n < buf.len() {
        match r.read(&mut buf[n..])? {
            0 => break,
            k => n += k,
        }
    }
    Ok(n)
}

/// Turns an archive member name into a relative path that can't leave the
/// output folder. Leading slashes are dropped, as tar does; `..`, drive
/// letters and NUL bytes are refused.
pub fn safe_path(name: &str) -> Option<PathBuf> {
    if name.contains('\0') {
        return None;
    }
    let mut out = PathBuf::new();
    for part in name.split(['/', '\\']) {
        match part {
            "" | "." => {}
            ".." => return None,
            p if p.contains(':') => return None,
            p => out.push(p),
        }
    }
    let clean = out.components().all(|c| matches!(c, Component::Normal(_)));
    (clean && !out.as_os_str().is_empty()).then_some(out)
}

/// Unix permission bits as 7-Zip and Info-ZIP store them in the high half of
/// the Windows attributes.
fn unix_mode_from_attributes(attrs: u32) -> Option<u32> {
    (attrs & 0x8000 != 0).then_some(attrs >> 16)
}

const S_IFMT: u32 = 0o170000;
const S_IFLNK: u32 = 0o120000;

fn is_symlink_mode(mode: Option<u32>) -> bool {
    mode.is_some_and(|m| m & S_IFMT == S_IFLNK)
}
